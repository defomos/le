$github-loop-runner

Run the worker loop for this repository.

Advance at most one eligible GitHub Issue. Only pick issues labelled both `risk:low` and `agent:ready`. Update `docs/loop-state.md` every run. Stop at human gates instead of guessing. Run `npm test` before reporting implementation success. If a pull request is ready, report the branch and proposed PR title instead of pushing unless the human explicitly approved push and PR creation for this run.
