$backlog-manager

Run the manager loop for this repository.

Default to DRY-RUN unless the human explicitly says apply mode is approved. Inspect open GitHub Issues, classify risk and type, identify which issues are safe for the worker loop, and report the exact labels and Agent Assessment comments you would apply.

Rules:
- Change nothing in DRY-RUN mode.
- Never write code.
- Never create branches or pull requests.
- Treat `agent:ready` as a permission grant.
- Only low-risk, clear, reversible work may become `agent:ready`.
- Mark ambiguous or risky work as `needs:human` with a specific question.
