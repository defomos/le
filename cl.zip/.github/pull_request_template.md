## Summary

-

## Loop Artifacts

- Issue:
- Task:
- Research:
- Plan:
- Implementation:
- Review:

## Checks

- [ ] `npm test` passes locally
- [ ] GitHub Actions quality check passes
- [ ] Human gates were respected
- [ ] No private or proprietary information was added
