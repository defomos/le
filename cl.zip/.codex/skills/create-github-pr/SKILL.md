---
name: create-github-pr
description: Prepare or create a GitHub Pull Request for an approved loop task.
---

# Create GitHub PR

Prepare pull request handoff after implementation and review.

## Rules

- Confirm `review.md` verdict is `APPROVED`.
- Run `npm test` immediately before PR handoff.
- Ask for human approval before pushing or creating a pull request.
- Keep PR title tied to the issue number.

## Commands

Use these commands when approved:

```bash
git status --short
git add <changed-files>
git commit -m "feat: GH-<number> - <short summary>"
git push --set-upstream origin <branch>
gh pr create --draft --title "feat: GH-<number> <short summary>" --body-file .github/pull_request_template.md
```

If live GitHub access is unavailable, report the exact branch name, commit message, and PR title that would be used.
