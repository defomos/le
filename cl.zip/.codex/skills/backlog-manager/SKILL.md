---
name: backlog-manager
description: Classify GitHub Issues for loop engineering by risk, type, and agent readiness. Use from Codex automation or when asked to triage the backlog.
---

# Backlog Manager

Run the manager loop. This skill decides what is safe for the worker loop.

## Trigger

Use this skill when:

- a Codex automation asks to run the manager loop
- the user asks to triage GitHub Issues
- the user asks for a dry run of loop readiness

## Job Card

- JOB: classify and route GitHub Issues
- INPUTS: open issues, labels, linked pull requests, existing Agent Assessment comments
- ALLOWED: in apply mode only, labels and comments
- FORBIDDEN: code changes, branches, pull requests, merges, closing issues without merged-PR evidence
- OUTPUT: labelled issues plus an inspectable Agent Assessment
- EVALUATION: low-risk clear work is routed to `agent:ready`; risky or ambiguous work gets `needs:human` with a specific question

## Label Protocol

- Risk: `risk:low` or `risk:high`
- Type: `type:feature`, `type:bug`, `type:docs`, `type:test`, `type:refactor`, or `type:chore`
- Routing: `agent:ready` or `needs:human`

Treat `agent:ready` as a permission grant, not a status label.

## Modes

### DRY-RUN

Inspect issues and report exactly what would change. Change nothing.

### APPLY

Apply only the labels and comments reported by a successful dry run, after the human explicitly approves apply mode.

## Instructions

1. Read `AGENTS.md`, `README.md`, `docs/loop-cards.md`, and `docs/loop-state.md`.
2. Discover issues:
   - Prefer `gh issue list --state open --json number,title,labels,body,url --limit 50`.
   - If GitHub is unavailable, use `docs/examples/GH-001-check-markdown-links/issue.md` as the offline sample.
3. For each issue, classify risk:
   - `risk:low`: small, reversible, clear acceptance criteria, local tests can verify it.
   - `risk:high`: broad architecture, unclear behavior, security-sensitive changes, data migration, missing acceptance criteria, or hard-to-verify work.
4. Classify type with exactly one `type:*` label.
5. Mark `agent:ready` only when risk is low and no human judgment is needed.
6. Mark `needs:human` when a decision is required. Include a specific question.
7. Produce or update an Agent Assessment.
8. Update `docs/loop-state.md` only when the run is operating on local/offline demo artifacts. For live GitHub mode, GitHub Issues are the primary control plane.

## Agent Assessment Template

```markdown
## Agent Assessment

Risk: low
Type: feature
Agent-ready: yes

Reason: Small isolated behavior with clear acceptance criteria and `npm test` verification.
```

For human-gated work:

```markdown
## Agent Assessment

Risk: high
Type: feature
Agent-ready: no

Reason: The issue changes product behavior that is not specified.
Question: Which behavior should be used when input is empty?
```

## Output

Return:

- mode used
- issues inspected
- proposed or applied label changes
- proposed or applied Agent Assessment comments
- issues requiring human input
- whether the worker loop has eligible work
