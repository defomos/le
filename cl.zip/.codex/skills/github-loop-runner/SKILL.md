---
name: github-loop-runner
description: Orchestrate one worker loop for a safe GitHub Issue using durable artifacts, tests, human gates, and verifier review. Use from Codex automation or when asked to advance the worker loop.
---

# GitHub Loop Runner

Run the worker loop. This skill turns one safe issue into a reviewed pull request handoff.

## Trigger

Use this skill when:

- a Codex automation asks to run the worker loop
- the user asks to advance a GitHub Issue loop
- the user asks to run the workshop demo loop

## Inputs

Primary intake is one open GitHub Issue labelled both:

- `risk:low`
- `agent:ready`

The issue should also contain an Agent Assessment from `$backlog-manager`.

For offline demos, use `docs/examples/GH-001-check-markdown-links/issue.md` as the sample issue and explain that it stands in for a GitHub Issue.

## Job Card

- JOB: implement one safe issue and prepare PR handoff
- INPUTS: one `risk:low` + `agent:ready` issue, Agent Assessment, repo code, tests, loop state
- ALLOWED: lightweight loop artifacts, implementation branch or worktree, code changes, tests, PR draft after human approval
- FORBIDDEN: choosing untriaged work, widening scope, fixing unrelated findings inline, merging code
- OUTPUT: reviewed implementation with passing tests and PR handoff
- EVALUATION: implementation matches the issue and plan, tests pass, verifier approves, human can inspect the PR

## Rules

- Advance at most one issue per run.
- Prefer a dedicated worktree or clean branch for implementation work.
- Update `docs/loop-state.md` before ending every run.
- Stop at human gates instead of guessing.
- Do not pick issues missing `risk:low` or `agent:ready`.
- Do not push or create a pull request unless explicitly approved for that run.
- Do not add private URLs, credentials, customer names, proprietary project names, or copied private code.
- If unrelated work is discovered, create an evidence-backed issue instead of fixing it inline.

## Lightweight Artifact Set

Use four artifacts for the showcase:

- `task.md`: what the issue asks for and acceptance criteria
- `plan.md`: the small implementation plan and verification command
- `implementation.md`: what changed and verification result
- `review.md`: verifier verdict

## Human Gates

Stop and report when:

- issue scope is unclear
- Agent Assessment is missing
- issue is missing `risk:low` or `agent:ready`
- `plan.md` exists but the issue does not have `loop:plan-approved`
- tests fail after implementation
- verifier returns `NEEDS_WORK`
- push or pull request creation would be the next step

## Workflow

1. Read `AGENTS.md`, `docs/loop-cards.md`, and `docs/loop-state.md`.
2. Discover eligible issues:
   - Prefer `gh issue list --label risk:low --label agent:ready --state open --json number,title,labels,body,url --limit 10`.
   - If GitHub is unavailable in a workshop, use the offline sample issue.
3. Select the oldest eligible issue that is not marked `loop:done` or `needs:human`.
4. Read the Agent Assessment before doing any work.
5. Resolve the loop directory as `docs/loops/GH-<number>-<slug>/` for live issues or reuse `docs/examples/GH-001-check-markdown-links/` for the offline sample.
6. Route by missing artifact:
   - Missing `task.md`: create it from the issue.
   - Missing `plan.md`: create it, then stop for plan approval.
   - Missing `implementation.md` and plan is approved: implement the plan and run tests.
   - Missing `review.md`: spawn the `verifier` subagent or perform a read-only review if subagents are unavailable.
   - Review approved and tests pass: use `$create-github-pr` only after human approval.
7. Run `npm test` before claiming implementation success.
8. Update `docs/loop-state.md` with phase, status, gate, and next action.

## Output

Return:

- selected issue
- phase advanced
- files changed
- verification command and result
- current human gate, if any
- next safe action
